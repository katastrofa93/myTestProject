$(document).ready(function(){
    $('.buttonWriteMe').on('click', function(e){
        e.preventDefault();
        $(document.documentElement).animate({
            scrollTop: $('.developer-feedback').offset().top
            
        },1500)
    })
});