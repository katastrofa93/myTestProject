function init(){
    let getButtonDevDes = document.querySelector('.design_bnuttonDevDes_button');
    let getImage = document.querySelector('.design_img_image');
    let getImage2 = document.querySelector('.design_img_image2');
    

    getButtonDevDes.addEventListener('click', ()=>{
        if(getImage.style.cssText && getImage2.style.cssText){
            getImage.style.cssText = null;
            getImage2.style.cssText = null;
            getButtonDevDes.innerHTML = "Создай свой дизайн";
        }else{
            getImage.style.cssText = 
            `opacity: 0;
            max-width: 0;
            transition: opacity  2s`;
            getImage2.style.cssText = 
            `opacity: 1;
            max-width: 100%;
            transition: opacity 2s`;
            getButtonDevDes.innerHTML = "Правда круто!";
        }   
        
    });
}
window.onload = init;

