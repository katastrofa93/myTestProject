$(document).ready(function(){
    const getButtonSendMail = $('#sendMailAjax');
    getButtonSendMail.on('click', function(){
        let getGeneralForm = $('#generalForm');
        console.log(1);
        let getInputName = $('#name').val().trim();
        let getInputPhone = $('#phone').val().trim();
        let getInputEmail = $('#email').val().trim();
        let getTextarea = $('#textarea').val().trim();
        const phoneValidation = /^(\+7|7|8)?[\s\-]?\(?[489][0-9]{2}\)?[\s\-]?[0-9]{3}[\s\-]?[0-9]{2}[\s\-]?[0-9]{2}$/;
        const emailValidation = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
        
        if(getInputName === "" || !isNaN(getInputName) || getInputName.length < 2){
            alert('Проверте правельность ввода поле имя');
            return false;
        }else{
            console.log('Проверка прошла Имя');
        }

        if(getInputPhone === "" || isNaN(getInputPhone) || !phoneValidation.test(getInputPhone)){
            alert('Проверте правельность ввода поле Телефон');
            return false;
        }else{
            console.log('Проверка прошла Телефон');
        }

        if(getInputEmail === "" || !emailValidation.test(getInputEmail)){
            alert('Проверте правельность ввода поле Email');
            return false;
        }else{
            console.log('Проверка прошла Email');
        }

        if(getTextarea === "" || getTextarea.length < 5){
            alert('Проверте правельность ввода поле Текста');
        }else{
            console.log('Проверка прошла Текст');
        }

        if( $('#policyId').is(':checked') ) {
            alert('Спасибо за ознакомление'); 
        }else{
            alert('Ваше согласие обязательно'); 
            return false;
        }

        
        
            $.ajax({
                method: "POST",
                url: "sendMail.php",
                data: getGeneralForm.serialize(),
                befоreSend: function(){ 
                    $("#sendMailAjax").prop("disabled", true); // кнопка не активна пока отправляется форма
                },
                success: function(data) {
                    if(data){
                        getGeneralForm.trigger('reset');
                        /*$('#name').val('');
                        $('#phone').val('');
                        $('#email').val('');
                        $('#textarea').val('');*/
                        alert( "Ваше сообщение отправлено" );
                        $("#sendMailAjax").prop("disabled", false); // кнопка активна пока отправляется форма
                    }else{
                        alert( "Ошибка" );
                    }
                }
            });
    });
});    

