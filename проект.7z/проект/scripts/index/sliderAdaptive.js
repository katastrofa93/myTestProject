$(document).ready(function(){
    var slideNow = 1; //показывает первый слайд при загрузки страницы
    var slideCount = $('.viewport_track_slide').length; //количество слайдов
    
    var navBtnId = 0;
    var translateWidth = 0; //расстояние, на которое смещается наш viewport_track.
    var getButtonsSlide = $('.nav').length;
    
//выбираем кнопки слайдера
        $('.buttons-next').click(function() {
            nextSlide();
        });

        $('.buttons-prev').click(function() {
            prevSlide();
        });
//выбираем пагинацию слайдера
        $('.nav').click(function(e) { 
            navBtnId = $(this).index();
            if (navBtnId + 1 != slideNow) {
                
                translateWidth = -$('.viewport').width() * (navBtnId);
                $('.viewport_track').css({
                    'transform': 'translate(' + translateWidth + 'px, 0)',
                    '-webkit-transform': 'translate(' + translateWidth + 'px, 0)',
                    '-ms-transform': 'translate(' + translateWidth + 'px, 0)',
                });
                slideNow = navBtnId + 1;
            }
        });

        
   

//прописывасем функции для кнопок слайдера
    function nextSlide() {
        if (slideNow == slideCount || slideNow <= 0 || slideNow > slideCount) {
            $('.viewport_track').css('transform', 'translate(0, 0)');
            slideNow = 1;
            
        } else {
            translateWidth = -$('.viewport').width() * (slideNow);
            $('.viewport_track').css({
                'transform': 'translate(' + translateWidth + 'px, 0)',
                '-webkit-transform': 'translate(' + translateWidth + 'px, 0)',
                '-ms-transform': 'translate(' + translateWidth + 'px, 0)',
            });
            slideNow++;
        }
    }

    function prevSlide() {
        if (slideNow == 1 || slideNow <= 0 || slideNow > slideCount) {
            translateWidth = -$('.viewport').width() * (slideCount - 1);
            $('.viewport_track').css({
                'transform': 'translate(' + translateWidth + 'px, 0)',
                '-webkit-transform': 'translate(' + translateWidth + 'px, 0)',
                '-ms-transform': 'translate(' + translateWidth + 'px, 0)',
            });
            slideNow = slideCount;
        } else {
            translateWidth = -$('.viewport').width() * (slideNow - 2);
            $('.viewport_track').css({
                'transform': 'translate(' + translateWidth + 'px, 0)',
                '-webkit-transform': 'translate(' + translateWidth + 'px, 0)',
                '-ms-transform': 'translate(' + translateWidth + 'px, 0)',
            });
            slideNow--;
        }
    }
});