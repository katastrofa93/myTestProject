function onload(){ 
    let getButtonShowMore = document.querySelector('.showNovisible-slider');
    getButtonShowMore.addEventListener('click', function(){
        getInvisibleBlock = document.querySelector('.novisible-slider');
        if(getInvisibleBlock.style.maxHeight){
            getInvisibleBlock.style.maxHeight = null;
            getButtonShowMore.innerHTML = 'Показать еще';
        }else{
            getInvisibleBlock.style.maxHeight = getInvisibleBlock.scrollHeight + 'px';
            getButtonShowMore.innerHTML = 'Свернуть';
        }
    })
        

        
}
window.onload();